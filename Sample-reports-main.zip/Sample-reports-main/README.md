# ABAP
SAP ABAP Programs
these snippets of program is for practice purpose.
Run using SAP GUI -> SE38 (ABAP Editor)
